const frames= [
    "frames/f1.png",
    "frames/f2.png",
    "frames/f3.png",
    "frames/f4.png",
    "frames/f5.png",
    "frames/f6.png"
];